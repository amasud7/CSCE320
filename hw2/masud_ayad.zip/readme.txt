# run this line in terminal to install all relevant packages
pip install numpy pandas matplotlib scipy sci-kit-learn seaborn

